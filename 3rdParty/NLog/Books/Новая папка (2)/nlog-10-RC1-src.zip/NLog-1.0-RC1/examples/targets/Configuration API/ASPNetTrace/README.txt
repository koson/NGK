To open this example in VS2005 you need to get 
"Visual Studio 2005 Web Application Projects" component available at:

http://msdn.microsoft.com/asp.net/reference/infrastructure/wap/default.aspx
